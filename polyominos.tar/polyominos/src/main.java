import java.util.LinkedList;
import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;
import java.util.Collections;
import java.awt.Color;

public class main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Image2d img = new Image2d(300, 300);
		
		List<Polyomino> pol = TXTPolyomino.polyominoFromTxt("D:\\poly.txt");
		pol.get(0).rotation();
		pol.get(0).draw(img);
		
		Image2dViewer view = new Image2dViewer(img);

	}

}
