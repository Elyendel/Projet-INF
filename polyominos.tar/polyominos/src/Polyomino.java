import java.awt.*;
import java.util.Collections;
import java.util.LinkedList;

public class Polyomino {
	public java.util.List<ColoredPolygon> squares;
	private int sqSize = 10;
	
	public Polyomino(java.util.List<IntPair> squareCoordinates, Color color) {
		squares = Collections.synchronizedList(new LinkedList<ColoredPolygon>());
		
		for(int i = 0; i < squareCoordinates.size(); i ++) {
			int x = squareCoordinates.get(i).x;
			int y = squareCoordinates.get(i).y;
			int[] currentSquareX = {x, x, x + sqSize, x + sqSize};
			int[] currentSquareY = {y, y+sqSize, y + sqSize, y};
			this.squares.add(new ColoredPolygon(currentSquareX, currentSquareY, color));
		}
		
	}
	
	public void draw(Image2d img) {
		img.addPolyomino(this);
	}
	
	public void translate(int xT, int yT) {
		for(int i = 0; i < this.squares.size(); i ++) {
			this.squares.get(i).polygon.xpoints[0] += xT*sqSize;
			this.squares.get(i).polygon.xpoints[1] += xT*sqSize;
			this.squares.get(i).polygon.xpoints[2] += xT*sqSize;
			this.squares.get(i).polygon.xpoints[3] += xT*sqSize;
			this.squares.get(i).polygon.ypoints[0] += yT*sqSize;
			this.squares.get(i).polygon.ypoints[1] += yT*sqSize;
			this.squares.get(i).polygon.ypoints[2] += yT*sqSize;
			this.squares.get(i).polygon.ypoints[3] += yT*sqSize;
		}
	}
	
	public void rotation() {
		for(int i = 0; i < this.squares.size(); i ++) {
			for(int j = 0; j<3; j++) {
				//swap
				//this.squares.get(i).polygon.xpoints[j] = this.squares.get(i).polygon.xpoints[j+1 % 3];
				//this.squares.get(i).polygon.ypoints[j] = this.squares.get(i).polygon.ypoints[j+1 % 3];
			}
			
		}
	}
	
	
}