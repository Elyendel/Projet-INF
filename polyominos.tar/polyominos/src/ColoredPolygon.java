import java.awt.*;

public class ColoredPolygon {
	public Polygon polygon;
	
	public Color color;
	
	public ColoredPolygon(int[] x, int[] y, Color color) {
		this.polygon = new Polygon(x, y, x.length);
		this.color = color;
	}
}
